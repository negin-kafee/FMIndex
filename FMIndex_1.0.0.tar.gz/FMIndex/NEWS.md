```markdown
# FMIndex 1.0.0
* Initial release of FMIndex package.
